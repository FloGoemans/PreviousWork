*****************************************************
Description of files for SAS Coursework
*****************************************************


*******
The folder structure & files present in submission package
******
readme.txt
>coursework folder
	> Data
		formats.sas7bcat
		>q1 	
			> Raw		subjects2019.xlsx
			> Analysis      dm.sas7bdat
		>q2 	
			> Raw		cholesterol.xlsx
			> Analysis  	adeff.sas7bdat
		>q3 	
			> Raw		renalv12.dta
			> Analysis	adtte.sas	
		>q4 	
			> Raw		illness.xlsx
			> Analysis	illness.sas7bdat

	> Documents 	199035098_SAS_coursework.docx (all combined output + sas code appendix)

	> Logs	
		>q1	log and lst files produced when programs are executed
		>q2	log and lst files produced when programs are executed
		>q3	log and lst files produced when programs are executed
		>q4	log and lst files produced when programs are executed

	> Output
		>q1	q1_part2.rtf

		>q2	q2_figures.rtf

		>q3	q3_coxph.rtf
			q3_kmplot.rtf
			q3_summstats.rtf

		>q4	q4_symptom_summary.rtf

	> Programs
		>q1	q1_data.sas
			q1_part2.sas

		>q2	q2_adeff.sas
			q2_figures.sas

		>q3	q3_adtte.sas
			q3_coxph.sas
			q3_kmplot.sas
			q3_summstats.sas

		>q4	q4_macro.sas
			q4_symptom_summary.sas

		setup.sas
		formats.sas
		templates.sas


******
Running programs in another environment
******

The aim is to allow programs to run in a new environment as long as they are kept within the correct relative location within 
the coursework folder (which can be renamed and placed anywhere on the user's PC).

Each program within the programs subfolders can be run as a standalone program as all datasets are included in the package.

Each program dynamically sets the program name, current path and working directory and calls setup.sas, 
which in turn calls formats and templates to set up the environment in a consistent way.
No absolute paths have been used.

The way this is done is slightly different when using SAS GRID, if there are any problems with the dynamic assignment please let me know.
To manually override, here are the needed parameters before setup is called:
&question (set within individual programs)
&curpath (dynamically assigned)
&pgmname (dynamically assigned)
working directory (dynamically assigned)

question 4 Macro:
See q4_macro program for detailed information on how the macro should be used.
q4_sympton_summary gives a worked example of the macro in use as a standalone program that does not rely on options set within setup. 

*** end Readme
